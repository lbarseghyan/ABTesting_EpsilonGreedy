"""
A/B Testing with Epsilon Greedy algorithm for Python
====================================================

ABTesting_EpsilonGreedy is a complete package to do multi- armed bandit testing in python.
"""

from ABTesting_EpsilonGreedy import ABTesting_EpsilonGreedy
