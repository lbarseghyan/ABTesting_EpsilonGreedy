"""Top-level package for A/B Testing: Epsilon Greedy."""

__author__ = """Laura Barseghyan"""
__email__ = 'barseghyanlaura1@gmail.com'
__version__ = '0.1.0'
